﻿namespace EmployeeMVC.DTO
{
    public class ManagerDTO
    {
        public int ManagerId { get; set; }
        public string Mname { get; set; }
    }
}
